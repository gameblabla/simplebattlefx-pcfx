_________________
SIMPLE BATTLE FX 
_________________

SIMPLE BATTLE FX is the second playable NEC PC-FX homebrew game.
SIMPLE BATTLE FX is a very simple and primitive turn-by-turn rpg where your goal is to defeat your opponent.

This homebrew game should work on a retail NEC PC-FX.
If it does not, send me a mail at gameblabla@openmailbox.org

The first public non-playable NEC PC-FX game was a demo of Frog Feast.
And before SIMPLE BATTLE FX, trap15 worked (and still is) working on a PC-Engine emulator for PC-X.
However, it was not made public yet and i'm not even sure if it can run a single game.

Many thanks to trap15 for Liberis !

I hope i'll be able to work on a more complex homebrew game for NEC PC-FX.
Liberis still needs more work (and more examples)